rceptor() {
        PaginationInterceptor paginationInterceptor = new PaginationInterceptor();
        List<ISqlParser> sqlParserList = new ArrayList<>();
        // BlockAttackNoWhereSqlParser 阻止全表查询更新或删除
        sqlParserList.add(new BlockAttackNoWhereSqlParser());
        // TenantSqlParser tenantSqlParser = new TenantSqlParser();
        //
        // tenantSqlParser.setTenantHandler(new TenantHandler() {
        // @Override
        // public Expression getTenantId() {
        // //获取租户id
        // return new StringValue(staffUtil.getTenantId());
        // }
        //
        // @Override
        // public String getTenantIdColumn() {
        // return "tenant_id";
        // }
        //
        // @Override
        // public boolean doTableFilter(String tableName) {
        //
        // //判断有无进行认证
        // if(!SecurityUtils.getSubject().isAuthenticated()){
        // return true;
        // }
        //
        // // 这里可以判断是否过滤表
        // if (configProperties.getTableInterceptorList().contains(tableName)) {
        // return true;
        // }
        //
        // return false;
        // }
        // });
        //
        // sqlParserList.add(tenantSqlParser);
        paginationInterceptor.setSqlParserList(sqlParserList);
        return paginationInterceptor;
    }

    @Bean
    public ISqlInjector sqlInjector() {
        return new SuperSqlInjector();
    }
}
package com.goldcard.ec.tenant.config;

import java.time.Duration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisPassword;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisClientConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializer;

import com.goldcard.ec.common.redis.FastJson2JsonRedisSerializer;
import com.goldcard.ec.common.redis.KeyStringRedisSerializer;
import com.goldcard.ec.common.redis.RedisTemplate;
import com.goldcard.ec.common.redis.RedisUtil;

/**
 * @author chenfei
 * @date 2019-04-22 12:22
 */
@Configuration
public class RedisConfig {

    @Value("${spring.redis.host}")
    private String hostName;

    @Value("${spring.redis.password}")
    private String password;

    @Value("${spring.redis.port}")
    private Integer port;

    @Value("${spring.redis.timeout}")
    private Integer timeout;

    @Value("${spring.application.name}")
    private String keyPrefix;

    /**
     * Jedis配置
     * 
     * @return
     */
    @Bean
    public JedisConnectionFactory JedisConnectionFactory() {
        RedisStandaloneConfiguration redisStandaloneConfiguration = new RedisStandaloneConfiguration();
        redisStandaloneConfiguration.setHostName(hostName);
        redisStandaloneConfiguration.setPort(port);
        // 由于我们使用了动态配置库,所以此处省略
        // redisStandaloneConfiguration.setDatabase(database);
        redisStandaloneConfiguration.setPassword(RedisPassword.of(password));
        JedisClientConfiguration.JedisClientConfigurationBuilder jedisClientConfiguration =
            JedisClientConfiguration.builder();
        jedisClientConfiguration.connectTimeout(Duration.ofMillis(timeout));
        JedisConnectionFactory factory =
            new JedisConnectionFactory(redisStandaloneConfiguration, jedisClientConfiguration.build());
        return factory;
    }

    /**
     * 实例化 RedisTemplate 对象
     * 
     * @param redisConnectionFactory
     * @return
     */
    @Bean
    public RedisTemplate functionDomainRedisTemplate(RedisConnectionFactory redisConnectionFactory) {
        RedisTemplate redisTemplate = new RedisTemplate();
        initDomainRedisTemplate(redisTemplate, redisConnectionFactory);
        return redisTemplate;
    }

    /**
     * 引入自定义序列化
     * 
     * @return
     */
    @Bean
    public RedisSerializer fastJson2JsonRedisSerializer() {
        return new FastJson2JsonRedisSerializer<>(Object.class);
    }

    /**
     * 置数据存入 redis 的序列化方式
     * 
     * @param redisTemplate
     * @param factory
     */
    private void initDomainRedisTemplate(RedisTemplate redisTemplate, RedisConnectionFactory factory) {
        // 如果不配置Serializer，那么存储的时候缺省使用String，如果用User类型存储，那么会提示错误User can't cast to String！
        redisTemplate.setKeySerializer(new KeyStringRedisSerializer(keyPrefix));
        redisTemplate.setHashKeySerializer(new KeyStringRedisSerializer(keyPrefix));
        redisTemplate.setHashValueSerializer(new GenericJackson2JsonRedisSerializer());
        redisTemplate.setValueSerializer(fastJson2JsonRedisSerializer());
        // 关闭事务
        redisTemplate.setEnableTransactionSupport(false);
        redisTemplate.setConnectionFactory(factory);
    }

    /**
     * 注入封装RedisTemplate
     * 
     * @param redisTemplate
     * @return
     */
    @Bean
    public RedisUtil redisUtil(RedisTemplate redisTemplate) {
        RedisUtil redisUtil = new RedisUtil();
        redisUtil.setRedisTemplate(redisTemplate);
        return redisUtil;
    }

}
package com.goldcard.ec.tenant.constant;

/**
 * @author Eric Lee
 * @Description :Hint 分片类型，分片字段非SQL决定，而由其他外置条件决定
 * @Create on : 2019/6/28 15:26
 **/
public enum HintType {
    DATABASE_ONLY, DATABASE_TABLES, MASTER_ONLY
}
package com.goldcard.ec.tenant.constant;

/**
 * @author Eric Lee
 * @Description : TODO
 * @Create on : 2019/7/1 19:54
 **/
public enum KeyGeneratorEnum {
    SNOWFLAKE, UUID, LEAF_SEGMENT
}
package com.goldcard.ec.tenant.constant;

/**
 * @author Eric Lee
 * @Description : 分片类型
 * @Create on : 2019/6/28 15:48
 **/
public enum ShardingType {
    /**
     * 数据库分片
     */
    SHARDING_DATABASES,

    /**
     * 表分片
     */
    SHARDING_TABLES,

    /**
     * 数据库、表分片
     */
    SHARDING_DATABASES_AND_TABLES,

    /**
     * 主从
     */
    MASTER_SLAVE,

    /**
     * 主从分片
     */
    SHARDING_MASTER_SLAVE,

    /**
     * 加密
     */
    ENCRYPT;
}
package com.goldcard.ec.tenant.domain;

import lombok.Data;

import java.util.Date;

/**
 * @author Eric Lee
 * @Description : TODO
 * @Create on : 2019/7/1 19:50
 **/
@Data
public class Orders {
    /**
     * 订单id
     */
    private String id;

    /**
     * 业务平台的订单id
     */
    private String parentOrdersUuid;
    /**
     * 业务平台的订单编号
     */
    private String parentOrdersId;
    /**
     * 订单来源
     */
    private String orderOrigin;
    /**
     * 订单类型
     */
    private String orderType;
    /**
     * 创建时间
     */
    private Date adddate;
}
package com.goldcard.ec.tenant.domain;

import lombok.Data;

/**
 * @author Eric Lee
 * @Description : TODO
 * @Create on : 2019/7/1 20:20
 **/
@Data
public class OrdersDetail {
    /**
     * 订单明细id
     */
    private String id;

    /**
     * 订单id
     */
    private String ordersId;
    /**
     * 商品id
     */
    private String goodsId;
    /**
     * 商品名称
     */
    private String goodsName;
    /**
     * 商品属性
     */
    private String goodsKindname;
}
package com.goldcard.ec.tenant.domain;

import java.io.Serializable;
import java.time.LocalDateTime;

import org.springframework.format.annotation.DateTimeFormat;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml