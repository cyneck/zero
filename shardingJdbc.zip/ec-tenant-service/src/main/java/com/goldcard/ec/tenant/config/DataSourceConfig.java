>
        <dependency>
            <groupId>com.goldcard</groupId>
            <artifactId>ec-tenant-service-api</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter</artifactId>
        </dependency>

        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>

        <dependency>
            <groupId>com.baomidou</groupId>
            <artifactId>dynamic-datasource-spring-boot-starter</artifactId>
        </dependency>

        <dependency>
            <groupId>com.goldcard</groupId>
            <artifactId>ec-common</artifactId>
        </dependency>
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
        </dependency>
        <dependency>
            <groupId>org.apache.commons</groupId>
            <artifactId>commons-lang3</artifactId>
        </dependency>
        <dependency>
            <groupId>com.mchange</groupId>
            <artifactId>mchange-commons-java</artifactId>
        </dependency>
        <dependency>
            <groupId>org.apache.shardingsphere</groupId>
            <artifactId>sharding-core-api</artifactId>
            <version>4.0.0-RC1</version>
        </dependency>
        <dependency>
            <groupId>org.apache.shardingsphere</groupId>
            <artifactId>sharding-jdbc-core</artifactId>
            <version>4.0.0-RC1</version>
        </dependency>
        <dependency>
            <groupId>org.apache.commons</groupId>
            <artifactId>commons-dbcp2</artifactId>
            <version>2.2.0</version>
        </dependency>
        <dependency>
            <groupId>org.apache.shardingsphere</groupId>
            <artifactId>sharding-orchestration-core</artifactId>
            <version>4.0.0-RC1</version>
        </dependency>
    </dependencies>

    <!--  sonar 信息-->
    <profiles>
        <profile>
            <id>sonar</id>
            <activation>
                <activeByDefault>true</activeByDefault>
            </activation>
            <properties>
                <!-- sonar数据库地址 -->
                <sonar.jdbc.url>jdbc:mysql://10.200.1.153:3306/sonar?useUnicode=true&amp;characterEncoding=utf8&amp;rewriteBatchedStatements=true&amp;useConfigs=maxPerformance&amp;useSSL</sonar.jdbc.url>
                <sonar.jdbc.username>iotapp</sonar.jdbc.username>
                <sonar.jdbc.password>IoT300349</sonar.jdbc.password>
                <!-- sonar服务器地址 -->
                <sonar.host.url>http://10.30.2.217:9000</sonar.host.url>
                <!-- 支持lombok -->
                <sonar.java.libraries>lib/lombok-1.18.8.jar</sonar.java.libraries>
                <!-- 配置字符编码 -->
                <sonar.sourceEncoding>UTF-8</sonar.sourceEncoding>
                <!-- 将在Web界面上显示的项目的名称。 -->
                <sonar.projectName>ec-tenant-service</sonar.projectName>
                <!-- 项目版本 -->
                <sonar.projectVersion>1.0.0</sonar.projectVersion>
                <!-- jacoco.xml文件路径-->
                <!--<sonar.coverage.jacoco.xmlReportPaths>target/site/jacoco/jacoco.xml</sonar.coverage.jacoco.xmlReportPaths>-->
                <!-- 排除测试覆盖率的类 -->
                <sonar.coverage.exclusions>**/domain/**, **/config/**, **/*Application.java</sonar.coverage.exclusions>

            </properties>
        </profile>
    </profiles>

    <build>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
            </plugin>
            <!-- 生成单元测试覆盖率 -->
            <plugin>
                <groupId>org.jacoco</groupId>
                <artifactId>jacoco-maven-plugin</artifactId>
                <version>0.8.3</version>
                <configuration>
                    <!--要扫描测试的类-->
                    <!--<includes>-->
                        <!--<include>com/chinagoldcard/ec/tenant/controller/*</include>-->
                        <!--<include>com/chinagoldcard/ec/tenant/service/impl/*</include>-->
                    <!--</includes>-->
                </configuration>
                <executions>
                    <execution>
                        <goals>
                            <goal>prepare-agent</goal>
                            <goal>report</goal>
                        </goals>
                    </execution>
                </executions>
            </plugin>
        </plugins>
        <resources>
            <!--编译之后包含xml-->
            <resource>
                <directory>src/main/java</directory>
                <includes>
                    <include>**/*.xml</include>
                </includes>
                <filtering>true</filtering>
            </resource>
        </resources>
    </build>
</project>
mvn sonar:sonar  -Dsonar.projectKey=ec-tenant-service  -Dsonar.host.url=http://192.168.48.130:19000  -Dsonar.login=74c371d32deb15ecb79c7b7ab80e5ac7cd153b47package com.goldcard.ec.tenant.config;

import org.apache.shardingsphere.api.sharding.standard.PreciseShardingAlgorithm;
import org.apache.shardingsphere.api.sharding.standard.PreciseShardingValue;

import java.util.Collection;

/**
 * @author Eric Lee
 * @Description : 数据库,精确分片算法，用于=和IN
 * @Create on : 2019/6/27 10:59
 **/
public class DataBasePreciseRule implements PreciseShardingAlgorithm<String> {

    /**
     * 分片规则
     *
     * @param availableSchemaNames 可用的数据库名
     * @param shardingValue        分片列
     * @return
     */
    @Override
    public String doSharding(Collection<String> availableSchemaNames, PreciseShardingValue<String> shardingValue) {
        // 分片字段值
        String value = shardingValue.getValue();
        // 现在算法是:%2 求余如果是0则<schema>.<table>_0,如果是1则<schema>.<table>_1。但是由于id是字符串而且是很长的，所以截取最后一位然后转为Integer类型再求余
        value = value.substring(value.length() - 6, value.length() - 3);
        Integer number = Integer.valueOf(value);
        int result = number % (availableSchemaNames.size());
        for (String s : availableSchemaNames) {
            if (s.endsWith(result + "")) {
                return s;
            }
        }
        throw new UnsupportedOperationException();
    }
}
package com.goldcard.ec.tenant.config;

import com.goldcard.ec.tenant.constant.KeyGeneratorEnum;
import com.goldcard.ec.tenant.util.DataSourceUtil;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.shardingsphere.api.config.sharding.KeyGeneratorConfiguration;
import org.apache.shardingsphere.api.config.sharding.ShardingRuleConfiguration;
import org.apache.shardingsphere.api.config.sharding.TableRuleConfiguration;
import org.apache.shardingsphere.api.config.sharding.strategy.StandardShardingStrategyConfiguration;
import org.apache.shardingsphere.core.constant.properties.ShardingPropertiesConstant;
import org.apache.shardingsphere.shardingjdbc.api.ShardingDataSourceFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import javax.sql.DataSource;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * @author Eric Lee
 * @Description : 配置数据源
 * @Create on : 2019/6/27 17:58
 **/
@Configuration
public class DataSourceConfig {


  