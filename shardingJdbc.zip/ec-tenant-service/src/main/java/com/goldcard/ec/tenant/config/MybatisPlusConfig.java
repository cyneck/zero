  @Value("${mybatis-plus.mapper-locations}")
    private String mybatisPlus_mapperLocations;

    /**
     * 获取sqlSessionFactory实例
     *
     * @param shardingDataSource
     * @return
     * @throws Exception
     */
    @Bean
    @Primary
    public SqlSessionFactory sqlSessionFactory(DataSource shardingDataSource) throws Exception {
        SqlSessionFactoryBean sqlSessionFactoryBean = new SqlSessionFactoryBean();
        sqlSessionFactoryBean.setDataSource(shardingDataSource);
        sqlSessionFactoryBean.setMapperLocations(new PathMatchingResourcePatternResolver().getResources(mybatisPlus_mapperLocations));
        return sqlSessionFactoryBean.getObject();
    }

    @Bean
    @Primary
    public SqlSessionTemplate testSqlSessionTemplate(SqlSessionFactory sqlSessionFactory) {
        return new SqlSessionTemplate(sqlSessionFactory);
    }

    /**
     * 配置数据源
     *
     * @return
     * @throws SQLException
     */
    @Bean("shardingDataSource")
    public DataSource getShardingDataSource() throws SQLException {
        ShardingRuleConfiguration shardingRuleConfig = new ShardingRuleConfiguration();

        //分片表规则
        shardingRuleConfig.getTableRuleConfigs().add(getOrdersRuleConfiguration());
        shardingRuleConfig.getTableRuleConfigs().add(getOrdersDetailRuleConfiguration());

        //绑定逻辑表集合
        shardingRuleConfig.getBindingTableGroups().add("orders");
        shardingRuleConfig.getBindingTableGroups().add("orders_detail");

        //未配置分片规则的表将通过默认数据源定位
        shardingRuleConfig.setDefaultDataSourceName("shard_order_0");

        //默认分库策略
        shardingRuleConfig.setDefaultDatabaseShardingStrategyConfig(
                new StandardShardingStrategyConfiguration("id", new DataBasePreciseRule()));

        //默认分表策略
        shardingRuleConfig.setDefaultTableShardingStrategyConfig(
                new StandardShardingStrategyConfiguration("id", new DataTablePreciseRule()));

        //默认自增列值生成器配置，缺省将使用org.apache.shardingsphere.core.keygen.generator.impl.SnowflakeKeyGenerator
        //自增列值生成器类型，可自定义或选择内置类型：SNOWFLAKE/UUID/LEAF_SEGMENT
        //使用SNOWFLAKE算法，需要配置worker.id与max.tolerate.time.difference.milliseconds属性
        shardingRuleConfig.setDefaultKeyGeneratorConfig(new KeyGeneratorConfiguration(KeyGeneratorEnum.SNOWFLAKE.toString(), "id"));


        Properties prop = new Properties();
        //显示sql
        prop.setProperty(ShardingPropertiesConstant.SQL_SHOW.getKey(), "true");

        return ShardingDataSourceFactory.createDataSource(createDataSourceMap(), shardingRuleConfig, prop);
    }

    /**
     * 需要手动配置事务管理器
     *
     * @param shardingDataSource
     * @return
     */
    @Bean
    public DataSourceTransactionManager transactitonManager(DataSource shardingDataSource) {
        return new DataSourceTransactionManager(shardingDataSource);
    }

    /**
     * 分片表1,规则配置
     *
     * @return
     */
    public TableRuleConfiguration getOrdersRuleConfiguration() {
        TableRuleConfiguration result = new TableRuleConfiguration(
                "orders", "shard_order_$->{0..1}.orders_$->{0..1}");
        //生成主键
        result.setKeyGeneratorConfig(new KeyGeneratorConfiguration(KeyGeneratorEnum.SNOWFLAKE.toString(), "id"));
        return result;
    }

    /**
     * 分片表2,规则配置
     *
     * @return
     */
    public TableRuleConfiguration getOrdersDetailRuleConfiguration() {
        TableRuleConfiguration result = new TableRuleConfiguration(
                "orders_detail", "shard_order_$->{0..1}.orders_detail_$->{0..1}");
        //生成主键
        result.setKeyGeneratorConfig(new KeyGeneratorConfiguration(KeyGeneratorEnum.SNOWFLAKE.toString(), "id"));
        return result;
    }


    /**
     * 数据源与其名称的映射
     *
     * @return
     */
    private Map<String, DataSource> createDataSourceMap() {
        Map<String, DataSource> result = new HashMap<>();
        result.put("shard_order_0", DataSourceUtil.createDataSource("shard_order_0"));
        result.put("shard_order_1", DataSourceUtil.createDataSource("shard_order_1"));
        return result;
    }

}
package com.goldcard.ec.tenant.config;

import org.apache.shardingsphere.api.sharding.standard.PreciseShardingAlgorithm;
import org.apache.shardingsphere.api.sharding.standard.PreciseShardingValue;
import org.springframework.stereotype.Component;

import java.util.Collection;

/**
 * @author Eric Lee
 * @Description : 表，精确分片算法，用于=和IN
 * @Create on : 2019/6/27 11:00
 **/
public class DataTablePreciseRule implements PreciseShardingAlgorithm<String> {

    /**
     * 分片规则
     *
     * @param availableTableNames 可用的表名
     * @param shardingValue       分片列
     * @return
     */
    @Override
    public String doSharding(Collection<String> availableTableNames, PreciseShardingValue<String> shardingValue) {
        // 分片字段值
        String value = shardingValue.getValue();
        // 现在算法是:%2 求余如果是0则xmjbq_user0,如果是1则xmjbq_user1。但是由于id是字符串而且是很长的，所以截取最后一位然后转为Integer类型再求余
        value = value.substring(value.length() - 1, value.length());
        Integer number = Integer.valueOf(value);
        int result = number % (availableTableNames.size());
        for (String tableName : availableTableNames) {
            if (tableName.endsWith(result + "")) {
                return tableName;
            }
        }
        throw new UnsupportedOperationException();
    }
}
package com.goldcard.ec.tenant.config;

import org.apache.shardingsphere.api.sharding.hint.HintShardingAlgorithm;
import org.apache.shardingsphere.api.sharding.hint.HintShardingValue;

import java.util.ArrayList;
import java.util.Collection;

/**
 * @author Eric Lee
 * @Description : hint分片算法
 * @Create on : 2019/6/28 15:29
 **/
public final class ModuloHintShardingAlgorithm implements HintShardingAlgorithm<Long> {

    @Override
    public Collection<String> doSharding(final Collection<String> availableTargetNames, final HintShardingValue<Long> shardingValue) {
        Collection<String> result = new ArrayList<>();
        for (String each : availableTargetNames) {
            for (Long value : shardingValue.getValues()) {
                if (each.endsWith(String.valueOf(value % 2))) {
                    result.add(each);
                }
            }
        }
        return result;
    }
}
package com.goldcard.ec.tenant.config;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.mapping.Environment;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.ibatis.transaction.TransactionFactory;
import org.apache.ibatis.transaction.jdbc.JdbcTransactionFactory;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.baomidou.mybatisplus.core.injector.ISqlInjector;
import com.baomidou.mybatisplus.core.parser.ISqlParser;
import com.baomidou.mybatisplus.extension.plugins.PaginationInterceptor;
import com.goldcard.ec.common.mybatisplus.injector.SuperSqlInjector;
import com.goldcard.ec.common.mybatisplus.sqlparser.BlockAttackNoWhereSqlParser;
import org.springframework.context.annotation.Primary;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;

/**
 * @author chenfei
 * @date 2019-04-16 9:40
 */
@Configuration
public class MybatisPlusConfig {

    /**
     * 分页插件
     */
    @Bean
    public PaginationInterceptor paginationInte