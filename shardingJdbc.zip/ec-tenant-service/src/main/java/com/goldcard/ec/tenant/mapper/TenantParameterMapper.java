.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
@NoArgsConstructor
@AllArgsConstructor
public class Tenant implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "tenant_id", type = IdType.ID_WORKER_STR)
    private String tenantId;

    @TableField("organ_code")
    private String organCode;

    @TableField("company_name")
    private String companyName;

    @TableField("state")
    private String state;

    @TableField("contact_name")
    private String contactName;

    @TableField("create_staff_id")
    private String createStaffId;

    @TableField("create_time")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

    @TableField("modify_staff_id")
    private String modifyStaffId;

    @TableField("modify_time")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime modifyTime;

    @TableField("domain_name")
    private String domainName;

    @TableField("tname_short")
    private String tnameShort;

    @TableField("begin_date")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime beginDate;

    @TableField("end_date")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime endDate;

    @TableField("contact_phone")
    private String contactPhone;

    @TableField("logo_path")
    private String logoPath;

    @TableField("welcome_info")
    private String welcomeInfo;

    @TableField("sale_cust_name")
    private String saleCustName;

    @TableField("sale_tax_id_number")
    private String saleTaxIdNumber;

    @TableField("sale_open_bank")
    private String saleOpenBank;

    @TableField("sale_addr_and_tel")
    private String saleAddrAndTel;
}package com.goldcard.ec.tenant.domain;

import java.io.Serializable;
import java.util.Date;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tenant_config")

public class TenantConfig implements Serializable {
    private static final long serialVersionUID = 1L;

    @TableId(value = "tenant_id", type = IdType.ID_WORKER_STR)
    private String tenantId;

    @TableField("customize_reset_surplus")
    private String customizeResetSurplus;

    @TableField("print_repair_receipt")
    private String printRepairReceipt;

    @TableField("initial_cyc_qty")
    private String initialCycQty;

    @TableField("create_time")
    private Date createTime;

    @TableField("time_split_enable")
    private String timeSplitEnable;

    @TableField("adjust_ladder")
    private String adjustLadder;

    @TableField("cumulant_report_type")
    private String cumulantReportType;

    @TableField("cumulant_report_type_writable")
    private String cumulantReportTypeWritable;
}package com.goldcard.ec.tenant.domain;


import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;


@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tenant_parameter")
public class TenantParameter implements Serializable {
    private static final long serialVersionUID = 1L;

    @TableId(value = "tenant_ID", type = IdType.ID_WORKER_STR)
    private String tenantId;

    @TableField("read_decimal_digit")
    private String readDecimalDigit;

    @TableField("settle_model")
    private String settleModel;

    @TableField("api_url")
    private String apiUrl;

    @TableField("business_model")
    private String businessModel;

    @TableField("alarm_frequency")
    private String alarmFrequency;
}package com.goldcard.ec.tenant;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.transaction.jta.JtaAutoConfiguration;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication(scanBasePackages = {"com.goldcard"}, exclude = JtaAutoConfiguration.class)
@MapperScan("com.goldcard.ec.tenant.mapper")
public class EcTenantServiceApplication {

    public static void main(String[] args) {
        ConfigurableApplicationContext applicationContext = SpringApplication.run(EcTenantServiceApplication.class, args);
        System.out.println("启动成功");
    }

}
package com.goldcard.ec.tenant.mapper;

import com.goldcard.ec.tenant.domain.OrdersDetail;

import java.util.List;

/**
 * @author Eric Lee
 * @Description : TODO
 * @Create on : 2019/7/1 20:21
 **/
public interface OrdersDetailMapper {

    /**
     * @param ordersDetail
     * @return
     */
    int insertDetail(OrdersDetail ordersDetail);

    /**
     * 根据订单ID查询订单明细
     * @param orderId
     * @return
     */
    List<OrdersDetail> selectDetailByOrderId(String orderId);

    /**
     * @param name
     * @return
     */
    List<OrdersDetail> selectDetailByName(String name);

    /**
     * @param id
     * @return
     */
    List<OrdersDetail> selectDetailById(String id);
}
package com.goldcard.ec.tenant.mapper;

import com.goldcard.ec.tenant.domain.Orders;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author Eric Lee
 * @Description : TODO
 * @Create on : 2019/7/1 20:13
 **/
public interface OrdersMapper {

    /**
     * @param orders
     * @return
     */
    int insertOrders(Orders orders);

    /**
     * @param id
     * @return
     */
    Orders selectById(String id);

    /**
     * 分页查询
     *
     * @param id
     * @param current
     * @param pageSize
     * @return
     */
    List<Orders> queryOrdersPage(
            @Param("id") String id,
            @Param("current") int current,
            @Param("pageSize") int pageSize);

    /**
     * 根据id批量查询
     *
     * @param ids
     * @return
     */
    List<Orders> queryInById(@Param("ids") List<String> ids);

    /**
     * @param startTime
     * @param endTime
     * @return
     */
    List<Orders> queryBetweenDate(@Param("startTime") String startTime,
                                  @Param("endTime") String endTime);
}
package com.goldcard.ec.tenant.mapper;

import com.goldcard.ec.common.mybatisplus.mapper.SuperMapper;
import com.goldcard.ec.tenant.domain.TenantConfig;

public interface TenantConfigMapper extends SuperMapper<TenantConfig> {
    int updateTenantConfigVO(TenantConfig tenantConfig);
}package com.goldcard.ec.tenant.mapper;

import com.goldcard.ec.common.mybatisplus.mapper.SuperMapper;
import com.goldcard.ec.tenant.domain.Tenant;

public interface TenantMapper extends SuperMapper<Tenant> {
    int updateTenantVO(Tenant Tenant);
}package com.goldcard.ec.tenant.mapper;

import com.goldcard.ec.common.mybatisplus.mapper.SuperMapper;
import com.goldcard.ec.tenant.domain.T