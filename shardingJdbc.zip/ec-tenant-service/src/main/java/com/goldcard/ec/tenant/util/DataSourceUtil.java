enantParameter;

public interface TenantParameterMapper extends SuperMapper<TenantParameter> {
    int updateTenantParameterVO(TenantParameter tenantParameter);
}package com.goldcard.ec.tenant.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.goldcard.ec.common.bean.PageRsp;
import com.goldcard.ec.common.constant.CacheConstant;
import com.goldcard.ec.common.enums.RedisKeyEnum;
import com.goldcard.ec.common.enums.ResultCodeEnum;
import com.goldcard.ec.common.exception.BusinessException;
import com.goldcard.ec.common.mybatisplus.service.SuperServiceImpl;
import com.goldcard.ec.common.redis.RedisUtil;
import com.goldcard.ec.common.util.BeanMapperUtil;
import com.goldcard.ec.tenant.api.TenantService;
import com.goldcard.ec.tenant.domain.Tenant;
import com.goldcard.ec.tenant.domain.TenantConfig;
import com.goldcard.ec.tenant.domain.TenantParameter;
import com.goldcard.ec.tenant.dto.*;
import com.goldcard.ec.tenant.mapper.TenantConfigMapper;
import com.goldcard.ec.tenant.mapper.TenantMapper;
import com.goldcard.ec.tenant.mapper.TenantParameterMapper;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.Arrays;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author Eric Lee
 * @since 2019-05-20
 */
@RestController
@RequestMapping(value = "tenants")
public class TenantServiceImpl extends SuperServiceImpl<TenantMapper, Tenant> implements TenantService {

    @Autowired
    private TenantMapper tenantMapper;

    @Autowired
    private TenantConfigMapper tenantConfigMapper;

    @Autowired
    private TenantParameterMapper tenantParameterMapper;

    @Autowired
    RedisUtil redisUtil;

    @Override
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public Boolean saveOrUpdateTenantVO(TenantUpdateReqDTO tenantUpdateReqDTO) {
        Tenant tenantTmp = BeanMapperUtil.map(tenantUpdateReqDTO.getTenantDTO(), Tenant.class);
        TenantParameter tenantParameterTmp =
            BeanMapperUtil.map(tenantUpdateReqDTO.getTenantParameterDTO(), TenantParameter.class);
        TenantConfig tenantConfigTmp = BeanMapperUtil.map(tenantUpdateReqDTO.getTenantConfigDTO(), TenantConfig.class);

        LocalDateTime databaseTime = LocalDateTime.now();

        Tenant tenant = tenantMapper.selectById(tenantTmp.getTenantId());
        if (tenant == null) {
            tenantTmp.setCreateStaffId(tenantUpdateReqDTO.getStaffId());
            tenantTmp.setCreateTime(databaseTime);

            tenantMapper.insert(tenantTmp);
            if (null != tenantParameterTmp) {
                tenantParameterTmp.setTenantId(tenantTmp.getTenantId());
                tenantParameterMapper.insert(tenantParameterTmp);
            }
            if (null != tenantConfigTmp) {
                tenantConfigTmp.setTenantId(tenantTmp.getTenantId());
                tenantConfigMapper.insert(tenantConfigTmp);
            }
        } else {

            // 更新操作，并不需要所有字段数据都更新
            tenantTmp.setModifyStaffId(tenantUpdateReqDTO.getStaffId());
            tenantTmp.setModifyTime(databaseTime);
            tenantMapper.updateTenantVO(tenantTmp);
            if (null != tenantParameterTmp) {
                tenantParameterMapper.updateTenantParameterVO(tenantParameterTmp);
            }
            if (null != tenantConfigTmp) {
                tenantConfigMapper.updateTenantConfigVO(tenantConfigTmp);
            }
            redisUtil.del(RedisKeyEnum.TENANT.join(tenantTmp.getTenantId()));
        }
        return true;
    }

    @Override
    public PageRsp<TenantListRspDTO> getTenantList(TenantListReqDTO tenantListReqDTO) {
        QueryWrapper<Tenant> queryWrapper = new QueryWrapper<>();
        queryWrapper.lambda()
            .eq(StringUtils.isNotBlank(tenantListReqDTO.getState()), Tenant::getState, tenantListReqDTO.getState())
            .likeRight(StringUtils.isNotBlank(tenantListReqDTO.getDomainName()), Tenant::getDomainName,
                tenantListReqDTO.getDomainName())
            .likeRight(StringUtils.isNotBlank(tenantListReqDTO.getTnameShort()), Tenant::getTnameShort,
                tenantListReqDTO.getTnameShort())
            .likeRight(StringUtils.isNotBlank(tenantListReqDTO.getContactName()), Tenant::getContactName,
                tenantListReqDTO.getContactName())
            .likeRight(StringUtils.isNotBlank(tenantListReqDTO.getContactPhone()), Tenant::getContactPhone,
                tenantListReqDTO.getContactPhone())
            .ge(null != tenantListReqDTO.getBeginDateMin(), Tenant::getBeginDate, tenantListReqDTO.getBeginDateMin())
            .le(null != tenantListReqDTO.getBeginDateMax(), Tenant::getBeginDate, tenantListReqDTO.getBeginDateMax())
            .ge(null != tenantListReqDTO.getEndDateMin(), Tenant::getEndDate, tenantListReqDTO.getEndDateMin())
            .le(null != tenantListReqDTO.getEndDateMax(), Tenant::getEndDate, tenantListReqDTO.getEndDateMax())
            .orderByDesc(Tenant::getModifyTime);
        Page<Tenant> page = new Page<>(tenantListReqDTO.getCurrent(), tenantListReqDTO.getSize());
        if (null != tenantListReqDTO.getDescs()) {
            page.setDescs(Arrays.asList(tenantListReqDTO.getDescs()));
        }
        if (null != tenantListReqDTO.getAscs()) {
            page.setAscs(Arrays.asList(tenantListReqDTO.getAscs()));
        }
        IPage<Tenant> pageData = tenantMapper.selectPage(page, queryWrapper);

        PageRsp<TenantListRspDTO> pageRsp = new PageRsp<>();
        pageRsp.setCurrent(pageData.getCurrent()).setSize(pageData.getSize()).setTotal(pageData.getTotal());
        pageRsp.setRecords(BeanMapperUtil.mapList(pageData.getRecords(), TenantListRspDTO.class));
        return pageRsp;
    }

    @Override
    public TenantDetailRspDTO getTenantDetail(String tenantId) {
        String key = RedisKeyEnum.TENANT.join(tenantId);
        if (redisUtil.hasKey(key)) {
            return (TenantDetailRspDTO)redisUtil.get(key);
        }
        Tenant tenant = tenantMapper.selectById(tenantId);
        if (tenant == null) {
            throw new BusinessException(ResultCodeEnum.TENANT_EMPTY);
        }

        TenantParameter tenantParameter = tenantParameterMapper.selectById(tenantId);
        TenantConfig tenantConfig = tenantConfigMapper.selectById(tenantId);

        TenantDetailRspDTO tenantDetailRspDTO = BeanMapperUtil.map(tenant, TenantDetailRspDTO.class);
        tenantDetailRspDTO.setTenantDTO(BeanMapperUtil.map(tenant, TenantDTO.class));
        tenantDetailRspDTO.setTenantParameterDTO(BeanMapperUtil.map(tenantParameter, TenantParameterDTO.class));
        tenantDetailRspDTO.setTenantConfigDTO(BeanMapperUtil.map(tenantConfig, TenantConfigDTO.class));
        redisUtil.set(key, tenantDetailRspDTO, CacheConstant.DEFAULT_TIME_OUT);
        return tenantDetailRspDTO;
    }
}
package com.goldcard.ec.tenant.util;

import com.zaxxer.hikari.HikariDataSource;

import javax.sql.DataSource;

/**
 * @author Eric Lee
 * @Description : 创建数据库源
 * @Create on : 2019/6/28 15:51
 **/
public class DataSourceUtil {
    private static final String HOST = "localhost";

    private static final int PORT = 3306;

    private static final String USER_NAME = "root";

    private static final String PASSWORD = "root";

    public static DataSource createDataSource(final String dataSourceName) {
        HikariDataSource result = new HikariDataSource();
        result.setDriverClassName(com.mysql.cj.jdbc.Driver.class.getName());
        result.setJdbcUrl(Strin