erty="cumulantReportType" column="cumulant_report_type"/>
        <result property="cumulantReportTypeWritable" column="cumulant_report_type_writable"/>
    </resultMap>

    <sql id="columns">
        TENANT_ID,
        CUSTOMIZE_RESET_SURPLUS,
        PRINT_REPAIR_RECEIPT,
        INITIAL_CYC_QTY,
        CREATE_TIME,
        TIME_SPLIT_ENABLE,
        ADJUST_LADDER,
        CUMULANT_REPORT_TYPE,
        CUMULANT_REPORT_TYPE_WRITABLE
    </sql>

    <update id="updateTenantConfigVO"
            parameterType="com.goldcard.ec.tenant.domain.TenantConfig">
        UPDATE tenant_config
        <set>
            <if test="tenantId != null">
                tenant_id = #{ tenantId,jdbcType = VARCHAR},
            </if>
            <if test="customizeResetSurplus != null">
                customize_reset_surplus = #{ customizeResetSurplus,jdbcType = INTEGER},
            </if>
            <if test="printRepairReceipt != null">
                print_repair_receipt = #{ printRepairReceipt,jdbcType = INTEGER},
            </if>
            <if test="initialCycQty != null">
                initial_cyc_qty = #{ initialCycQty,jdbcType = INTEGER},
            </if>
            <if test="timeSplitEnable != null">
                time_split_enable = #{ timeSplitEnable,jdbcType = INTEGER},
            </if>
            <if test="adjustLadder != null">
                adjust_ladder = #{ adjustLadder,jdbcType = INTEGER},
            </if>
            <if test="cumulantReportType != null">
                cumulant_report_type = #{ cumulantReportType,jdbcType = INTEGER},
            </if>
            <if test="cumulantReportTypeWritable != null">
                cumulant_report_type_writable = #{ cumulantReportTypeWritable,jdbcType = INTEGER}
            </if>
        </set>
        where
        tenant_id = #{tenantId}
    </update>
</mapper><?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE mapper PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN" "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<mapper namespace="com.goldcard.ec.tenant.mapper.TenantMapper">
    <resultMap id="tenantMap"
               type="com.goldcard.ec.tenant.domain.Tenant">
        <id property="tenantId" column="tenant_id"/>
        <result property="organCode" column="organ_code"/>
        <result property="companyName" column="company_name"/>
        <result property="state" column="state"/>
        <result property="contactName" column="contact_name"/>
        <result property="createStaffId" column="create_staff_id"/>
        <result property="createTime" column="create_time"/>
        <result property="modifyStaffId" column="modify_staff_id"/>
        <result property="modifyTime" column="modify_time"/>
        <result property="domainName" column="domain_name"/>
        <result property="tnameShort" column="tname_short"/>
        <result property="beginDate" column="begin_date"/>
        <result property="endDate" column="end_date"/>
        <result property="contactPhone" column="contact_phone"/>
        <result property="logoPath" column="logo_path"/>
        <result property="welcomeInfo" column="welcome_info"/>
        <result property="saleCustName" column="sale_cust_name"/>
        <result property="saleTaxIdNumber" column="sale_tax_id_number"/>
        <result property="saleOpenBank" column="sale_open_bank"/>
        <result property="saleAddrAndTel" column="sale_addr_and_tel"/>
    </resultMap>

    <sql id="columns">
        TENANT_ID,
        ORGAN_CODE,
        COMPANY_NAME,
        STATE,
        CONTACT_NAME,
        CREATE_STAFF_ID,
        CREATE_TIME,
        MODIFY_STAFF_ID,
        MODIFY_TIME,
        DOMAIN_NAME,
        TNAME_SHORT,
        BEGIN_DATE,
        END_DATE,
        CONTACT_PHONE,
        LOGO_PATH,
        WELCOME_INFO,
        SALE_CUST_NAME,
        SALE_TAX_ID_NUMBER,
        SALE_OPEN_BANK,
        SALE_ADDR_AND_TEL
    </sql>

    <update id="updateTenantVO"
            parameterType="com.goldcard.ec.tenant.domain.Tenant">
        UPDATE tenant
        <set>
            <if test="tenantId != null">
                tenant_id = #{ tenantId,jdbcType = VARCHAR},
            </if>
            <if test="organCode != null">
                organ_code = #{ organCode,jdbcType = VARCHAR},
            </if>
            <if test="companyName != null">
                company_name = #{ companyName,jdbcType = VARCHAR},
            </if>
            <if test="state != null and state != ''">
                state = #{ state,jdbcType = VARCHAR},
            </if>
            <if test="contactName != null">
                contact_name = #{ contactName,jdbcType = VARCHAR},
            </if>
            <if test="createStaffId != null and createStaffId != ''">
                create_staff_id = #{ createStaffId,jdbcType = VARCHAR},
            </if>
            <if test="createTime != null">
                create_time = #{ createTime,jdbcType = TIMESTAMP},
            </if>
            <if test="modifyStaffId != null and modifyStaffId != ''">
                modify_staff_id = #{ modifyStaffId,jdbcType = VARCHAR},
            </if>
            <if test="modifyTime != null">
                modify_time = #{ modifyTime,jdbcType = TIMESTAMP},
            </if>
            <if test="domainName != null">
                domain_name = #{ domainName,jdbcType = VARCHAR},
            </if>
            <if test="tnameShort != null and tnameShort != ''">
                tname_short = #{ tnameShort,jdbcType = VARCHAR},
            </if>
            <if test="beginDate != null">
                begin_date = #{ beginDate,jdbcType = TIMESTAMP},
            </if>
            <if test="endDate != null">
                end_date = #{ endDate,jdbcType = TIMESTAMP},
            </if>
            <if test="contactPhone != null">
                contact_phone = #{ contactPhone,jdbcType = VARCHAR},
            </if>
            <if test="logoPath != null">
                logo_path = #{ logoPath,jdbcType = VARCHAR},
            </if>
            <if test="welcomeInfo != null">
                welcome_info = #{ welcomeInfo,jdbcType = VARCHAR},
            </if>
        </set>
        where
        tenant_id = #{tenantId}
    </update>
</mapper><?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE mapper PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN" "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<mapper namespace="com.goldcard.ec.tenant.mapper.TenantParameterMapper">
    <resultMap id="tenantParameterMap"
               type="com.goldcard.ec.tenant.domain.TenantParameter">
        <id property="tenantId" column="tenant_ID"/>
        <result property="readDecimalDigit" column="read_decimal_digit"/>
        <result property="settleModel" column="settle_model"/>
        <result property="apiUrl" column="api_url"/>
        <result property="businessModel" column="business_model"/>
        <result property="alarmFrequency" column="alarm_frequency"/>
    </resultMap>

    <sql id="columns">
        TENANT_ID,
        READ_DECIMAL_DIGIT,
        SETTLE_MODEL,
        API_URL,
        BUSINESS_MODEL,
        ALARM_FREQUENCY
    </sql>

    <update id="updateTenantParameterVO"
            parameterType="com.goldcard.ec.tenant.domain.TenantParameter">
        UPDATE tenant_parameter
        <set>
            <if test="tenantId != null">
                tenant_id = #{ tenantId,jdbcType = VARCHAR},
            </if>
            <if test="businessModel != null and businessModel != ''">
                business_model = #{ businessModel,jdbcType = VARCHAR},
            </if>
        </set>
        where
        tenant_ID = #{tenantId}
    </update>
</mapper>package com.goldcard.ec.tenant.service;

import com.baomidou.mybatisplus.extension.enums.ApiErrorCode;
import com.goldcard.ec.common.bean.PageRsp;
import com.goldcard.ec.common.constant.CacheConstant;
import com.goldcard.ec.common.enums.ResultCodeEnum;
import com.goldcard.ec.common.exception.BusinessException;
import com.goldcard.ec.common.redis.RedisUtil;
import com.goldcard.ec.common.util.JsonConvertUtil;
import com.goldcard.ec.tenant.api.TenantService;
import com.goldcard.ec.tenant.domain.Orders;
import com.goldcard.ec.tenant.domain.OrdersDetail;
import com.goldcard.ec.tenant.dto.*;
import com.goldcard.ec.tenant.mapper.OrdersDetailMapper;
import com.goldcard.ec.tenant.mapper.OrdersMapper;
import com.goldcard.ec.tenant.util.KeyGeneratorUtil;
import com.mchange.io.FileUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.WebApplicationContext;

import javax.annotation.Resource;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Random;

/**
 * @author Eric Lee
 * @version v1.0.0
 * @Package : com.goldcard.ec.tenant.service
 * @Description : 租住单元测试
 * @Create on : 2019/6/14 11:12
 **/
//@Transactional // 避免测试数据污染环境
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
public class TenantServiceTest {

    // 单元测试，租户有关测试数据的资源文件父级路径
    private final String baseParh = "test/";

    @Autowired
    TenantService tenantService;

    @SpyBean
    RedisUtil redisUtil;

    @Autowired
    OrdersMapper ordersMapper;

    @Autowired
    OrdersDetailMapper ordersDetailMapper;

    @Resource
    private WebApplicationContext webApplicationContext;

    private MockMvc mockMvc;
    private MockHttpServletRequest mockHttpServletRequest;
    private MockHttpServletResponse mockHttpServletResponse;
    protected MockHttpSession session;

    @Before
    public void setup() {
        mockHttpServletRequest = new MockHttpServletRequest(webApplicationContext.getServletContext());
        mockHttpServletResponse = new MockHttpServletResponse();
        MockHttpSession mockHttpSession = new MockHttpSession(webApplicationContext.getServletContext());
        mockHttpServletRequest.setSession(mockHttpSession);
        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
    }

    /**
     * 在代码中打桩(stub),示例
     *
     * @throws IOException
     */
    @Test
    public void mockitoExampleUpdateTest() throws IOException {
        String fielPath = getClass().getClassLoader().getResource(baseParh + "saveTenantVoTest.json").getPath();
        File file = new File(fielPath);
        if (file.exists()) {
            // 构造数据
            String testJson = FileUtils.getContentsAsString(file);
            TenantUpdateReqDTO tenantUpdateReqDTO = JsonConvertUtil.jsonToObject(testJson, TenantUpdateReqDTO.class);

            // 设置期望
            Boolean expectedResult = Boolean.TRUE;

            // 创建一个mock对象，或者通过属性注解的方式SpringBoot封装框架使用@MockBean，当对ApplicationContext有依赖是，有限使用；原生mockito框架使用@Mock
            TenantService mockBean = Mockito.mock(TenantService.class);

            // 创建一个测试桩stub，定义在service层关于dao层语句的返回值定义，使得service代码的测试脱离开dao层。
            Mockito.when(mockBean.saveOrUpdateTenantVO(tenantUpdateReqDTO)).thenReturn(expectedResult);

            // 执行方法
            Boolean actualResult = mockBean.saveOrUpdateTenantVO(tenantUpdateReqDTO);

            // 验证调用方法是否执行过
            Mockito.verify(mockBean).saveOrUpdateTenantVO(tenantUpdateReqDTO);

            // 断言
            Assert.assertTrue(ApiErrorCode.FAILED.toString(), actualResult == expectedResult);
        }

    }

    /**
     * 在代码中打桩(stub),示例
     *
     * @throws IOException
     */
    @Test
    public void mockitoExampleGetTest() {
        // 构造数据
        // 设置期望
        TenantDetailRspDTO expectedResult = new TenantDetailRspDTO();
        expectedResult.setTenantDTO(new TenantDTO().setTenantId("0000"));
        expectedResult.setTenantParameterDTO(new TenantParameterDTO().setTenantId("0000"));
        expectedResult.setTenantConfigDTO(new TenantConfigDTO().setTenantId("0000"));

        // 创建一个mock对象，或者通过属性注解的方式SpringBoot封装框架使用@MockBean，当对ApplicationContext有依赖时可以使用；原生mockito框架使用@Mock
        TenantService mockBean = Mockito.mock(TenantService.class);

        // 创建一个测试桩stub，定义在service层该方法的返回值定义，使得service代码的测试脱离开dao层。
        Mockito.when(mockBean.getTenantDetail("0000")).thenReturn(expectedResult);

        // 执行方法，使用模拟对象
        TenantDetailRspDTO actualResult = mockBean.getTenantDetail("0000");

        // 验证调用方法是否执行过
        Mockito.verify(mockBean).getTenantDetail("0000");

        // 断言
        Assert.assertTrue(ApiErrorCode.FAILED.toString(), actualResult.getTenantDTO().getTenantId() == "0000");

    }

    /**
     * 修改保存租户详细信息测试
     *
     * @throws IOException
     */
    @Test
    public void saveTenantVoTest() throws IOException {
        String fielPath = getClass().getClassLoader().getResource(baseParh + "saveTenantVoTest.json").getPath();
        File file = new File(fielPath);
        if (file.exists()) {
            String testJson = FileUtils.getContentsAsString(file);
            TenantUpdateReqDTO tenantUpdateReqDTO = JsonConvertUtil.jsonToObject(testJson, TenantUpdateReqDTO.class);
            Assert.assertTrue(ApiErrorCode.FAILED.toString(), tenantService.saveOrUpdateTenantVO(tenantUpdateReqDTO));
        }

    }

    /**
     * 修改保存租户dto数据对象，从表没有数据
     *
     * @throws IOException
     */
    @Test
    public void saveTenantDtoTest() throws IOException {
        String fielPath = getClass().getClassLoader().getResource(baseParh + "saveTenantDtoTest.json").getPath();
        File file = new File(fielPath);
        if (file.exists()) {
            String testJson = FileUtils.getContentsAsString(file);
            TenantUpdateReqDTO tenantUpdateReqDTO = JsonConvertUtil.jsonToObject(testJson, TenantUpdateReqDTO.class);
            Assert.assertTrue(ApiErrorCode.FAILED.toString(), tenantService.saveOrUpdateTenantVO(tenantUpdateReqDTO));
        }

    }

    /**
     * 新增租户详细信息测试
     *
     * @throws IOException
     */
    @Test
    public void addTenantVoTest() throws IOException {
        String fielPath = getClass().getClassLoader().getResource(baseParh + "addTenantVoTest.json").getPath();
        File file = new File(fielPath);
        if (file.exists()) {
            String testJson = FileUtils.getContentsAsString(file);
            TenantUpdateReqDTO tenantUpdateReqDTO = JsonConvertUtil.jsonToObject(testJson, TenantUpdateReqDTO.class);
            tenantUpdateReqDTO.setStaffId("00");
            Assert.assertTrue(tenantService.saveOrUpdateTenantVO(tenantUpdateReqDTO));
        }

    }

    /**
     * dto对象没有从表数据
     *
     * @throws IOException
     */
    @Test(timeout = 4000)
    public void addTenantDtoTest() throws IOException {
        String fielPath = get