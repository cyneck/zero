Class().getClassLoader().getResource(baseParh + "addTenantDtoTest.json").getPath();
        File file = new File(fielPath);
        if (file.exists()) {
            String testJson = FileUtils.getContentsAsString(file);
            TenantUpdateReqDTO tenantUpdateReqDTO = JsonConvertUtil.jsonToObject(testJson, TenantUpdateReqDTO.class);
            Assert.assertTrue(ApiErrorCode.FAILED.toString(), tenantService.saveOrUpdateTenantVO(tenantUpdateReqDTO));
        }

    }

    /**
     * 分页全表查询
     *
     * @throws IOException
     */
    @Test
    public void getTenantAllPage() throws IOException {
        String fielPath = getClass().getClassLoader().getResource(baseParh + "getTenantAllPage.json").getPath();
        File file = new File(fielPath);
        if (file.exists()) {
            String testJson = FileUtils.getContentsAsString(file);
            TenantListReqDTO tenantListReqDTO = JsonConvertUtil.jsonToObject(testJson, TenantListReqDTO.class);
            PageRsp listRspDTOPageBean = tenantService.getTenantList(tenantListReqDTO);
            Assert.assertTrue(ApiErrorCode.FAILED.toString(), listRspDTOPageBean.getTotal() != 0);
        }
    }

    /**
     * 分页测试，获取租户列表测试
     *
     * @throws IOException
     */
    @Test
    public void getTenantListPageByCurrentTest() throws IOException {
        String fielPath =
                getClass().getClassLoader().getResource(baseParh + "getTenantListPageByCurrentTest.json").getPath();
        File file = new File(fielPath);
        if (file.exists()) {
            String testJson = FileUtils.getContentsAsString(file);
            TenantListReqDTO tenantListReqDTO = JsonConvertUtil.jsonToObject(testJson, TenantListReqDTO.class);
            PageRsp listRspDTOPageBean = tenantService.getTenantList(tenantListReqDTO);
            Assert.assertTrue(ApiErrorCode.FAILED.toString(), listRspDTOPageBean.getTotal() != 0);
        }
    }


    /**
     * 查看租户详细数据测试
     */
    @Test
    public void getTenantVoDetailTest() {
        TenantDetailRspDTO tenantDetailRspDTO = tenantService.getTenantDetail("0000");
        Assert.assertNotNull(tenantDetailRspDTO);
        Assert.assertTrue(ApiErrorCode.FAILED.toString(), tenantDetailRspDTO.getTenantDTO().getTenantId().equals("0000"));
    }

    /**
     * 查看租户详细为空
     */
    @Test
    public void getTenantVoDetailNullTest() {
        // 设置期望
        BusinessException expectedResult = new BusinessException(ResultCodeEnum.TENANT_EMPTY);
        try {
            TenantDetailRspDTO tenantDetailRspDTO = tenantService.getTenantDetail("");
            Assert.assertNull(tenantDetailRspDTO);
        } catch (Exception e) {

            Assert.assertTrue(ApiErrorCode.FAILED.toString(), expectedResult.getMessage().equals(e.getMessage()));

        }
    }

    @Test
    public void mockDependent() {

        //构造数据
        String tenantId = "1234";
        TenantDetailRspDTO expectedResult = new TenantDetailRspDTO();
        expectedResult.setTenantDTO(new TenantDTO().setTenantId(tenantId));

        //构造、模拟注入依赖的数据
        String key = CacheConstant.TENANT_DETAIL + tenantId;
//        Mockito.when(redisUtil.get(key)).thenReturn(expectedResult);
        Mockito.doReturn(true).when(redisUtil).hasKey(key);
        Mockito.doReturn(expectedResult).when(redisUtil).get(key);

        // 执行mock的类方法
        TenantDetailRspDTO tenantDetailRspDTO = (TenantDetailRspDTO) redisUtil.get(key);

        //执行真实调用过程
        TenantDetailRspDTO tenantDetail = tenantService.getTenantDetail(tenantId);

        //验证调用方法是否执行过
        Assert.assertNotNull(tenantDetail);
        Assert.assertTrue(ApiErrorCode.FAILED.toString(), tenantDetailRspDTO.getTenantDTO().getTenantId().equals(tenantDetail.getTenantDTO().getTenantId()));
    }

    /**
     * 插入数据，分库
     */
    @Test
    public void batchInitData() {
        for (int i = 0; i < 10; i++) {
            Orders orders = new Orders();
            String orderId = String.valueOf(KeyGeneratorUtil.geneateSnowFlake().nextId());
            orders.setId(orderId);
            orders.setAdddate(new Date());
            orders.setOrderType("1");
            orders.setOrderOrigin("2");
            orders.setParentOrdersId("222211" + (new Random().nextInt(1000)));
            orders.setParentOrdersUuid("333333");
            ordersMapper.insertOrders(orders);

            OrdersDetail ordersDetail = new OrdersDetail();
            ordersDetail.setId(String.valueOf(KeyGeneratorUtil.geneateSnowFlake().nextId()));
            ordersDetail.setOrdersId(orderId);
            ordersDetail.setGoodsId((new Random().nextInt(1000) + "3333"));
            ordersDetail.setGoodsName("测试商品" + (new Random().nextInt(1000)));
            ordersDetailMapper.insertDetail(ordersDetail);
        }
    }

    /**
     * 分库查询(水平分库分表)
     */
    @Test
    public void queryOrdersPage() {
        List<Orders> orders = ordersMapper.queryOrdersPage("343456251423752192", 0, 10);
        Assert.assertNotNull(orders);
        Assert.assertTrue(orders.size() != 0);
    }

}
package com.goldcard.ec.tenant.service;

import org.junit.Test;

import java.io.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * @author Eric Lee
 * @Description : TODO
 * @Create on : 2019/7/2 18:37
 **/
public class test {

    @Test
    public void test() {
        ZipCompress zipCom = new ZipCompress("D:\\shardingJdbc.zip", "D:\\svn\\DEMO\\trunk\\ec-tenant-service");
        try {
            zipCom.zip();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    class ZipCompress {
        private String zipFileName;      // 目的地Zip文件
        private String sourceFileName;   //源文件（带压缩的文件或文件夹）

        public ZipCompress(String zipFileName, String sourceFileName) {
            this.zipFileName = zipFileName;
            this.sourceFileName = sourceFileName;
        }

        public void zip() throws Exception {
            //File zipFile = new File(zipFileName);
            System.out.println("压缩中...");

            //创建zip输出流
            ZipOutputStream out = new ZipOutputStream(new FileOutputStream(zipFileName));

            //创建缓冲输出流
            BufferedOutputStream bos = new BufferedOutputStream(out);

            File sourceFile = new File(sourceFileName);

            //调用函数
            compress(out, bos, sourceFile, sourceFile.getName());

            bos.close();
            out.close();
            System.out.println("压缩完成");

        }

        public void compress(ZipOutputStream out, BufferedOutputStream bos, File sourceFile, String base) throws Exception {
            //如果路径为目录（文件夹）
            if (sourceFile.isDirectory()) {

                //取出文件夹中的文件（或子文件夹）
                File[] flist = sourceFile.listFiles();

                if (flist.length == 0)//如果文件夹为空，则只需在目的地zip文件中写入一个目录进入点
                {
                    System.out.println(base + "/");
                    out.putNextEntry(new ZipEntry(base + "/"));
                } else//如果文件夹不为空，则递归调用compress，文件夹中的每一个文件（或文件夹）进行压缩
                {
                    for (int i = 0; i < flist.length; i++) {
                        compress(out, bos, flist[i], base + "/" + flist[i].getName());
                    }
                }
            } else//如果不是目录（文件夹），即为文件，则先写入目录进入点，之后将文件写入zip文件中
            {
                out.putNextEntry(new ZipEntry(base));
                FileInputStream fos = new FileInputStream(sourceFile);
   